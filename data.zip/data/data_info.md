# Data Structure

This document describes the structure and format of data files in the `data` folder.

## Folder Structure

The `data` folder has the following structure:
- `EEDI`: EEDI dataset
    - `eedi_data.json`: Consolidated EEDI dataset for survey simulations
    - `synthetic_answers`: Synthetic answers for the EEDI dataset
        - `raw`: Raw synthetic answers
            - `{llm_name}.json`: Raw synthetic answers for the EEDI dataset from the LLM `{llm_name}`
        - `clean`: Clean synthetic answers
            - `{llm_name}.json`: Clean synthetic answers for the EEDI dataset from the LLM `{llm_name}`
            - `random.json`: Clean synthetic answers for the EEDI dataset from random sampling
- `OpinionQA`: OpinionQA dataset
    - `opinionqa_data.json`: Consolidated OpinionQA dataset for survey simulations
    - `synthetic_answers`: Synthetic answers for the OpinionQA dataset
        - `raw`: Raw synthetic answers
            - `{llm_name}.json`: Raw synthetic answers for the OpinionQA dataset from the LLM `{llm_name}`
        - `clean`: Clean synthetic answers
            - `{llm_name}.json`: Clean synthetic answers for the OpinionQA dataset from the LLM `{llm_name}`
            - `random.json`: Clean synthetic answers for the OpinionQA dataset from random sampling

## `eedi_data.json`

Consolidated EEDI dataset for survey simulations. Contains question metadata, answers, survey responses, and synthetic profiles for selected questions. 

**File Format**: JSON object keyed by question IDs ("0", "1", "2", ..., "411"). Each entry is a dictionary with the following keys:

* `old_id` (int): Original question ID from the EEDI dataset
* `question` (str): Question/problem statement
* `answer` (int): Correct answer index from {1, 2, 3, 4}, corresponding to choices {"A", "B", "C", "D"}
* `answer_to_letter` (dict): Dictionary that maps an answer string to a choice in {"A", "B", "C", "D"}
* `survey` (list of dicts): Survey response records for this question with `records` orientation (i.e., obtained from `df.to_dict(orient='records')`). An example record: 
```
{
    'UserId': 5,
    'IsCorrect': 1,
    'CorrectAnswer': 1,
    'AnswerValue': 1,
    'Gender': 1,
    'PremiumPupil': 0.0,
    'age': 11
}
```
This list of records can be turned into a `pandas.DataFrame` by `pandas.DataFrame(..)`. The dataframe contains columns `['UserId', 'IsCorrect', 'CorrectAnswer', 'AnswerValue', 'Gender']`
* `synthetic_profile` (list of dicts): Synthetic profile records for this question with `records` orientation (i.e., obtained from `df.to_dict(orient='records')`). The length is 200. An example record: 
```
{
    'Gender': 2.0,
    'PremiumPupil': 0.0,
    'Age': 11.0,
    'PROMPT': 'Pretend that you are an 11-year-old student. Your gender is male. You are not eligible for free school meals or pupil premium due to being relatively financially advantaged. Given your characteristics, is it likely that you would be able to solve the following problem? \n\nProblem: If you multiply a square number by 9, you get a square number. Is this statement:\n\nA. always true\nB. sometimes true\nC. never true\nD. impossible to say \n\nIf yes, put the final answer choice (a single letter) in double square brackets. If you are likely to struggle with this problem, put a plausible incorrect answer choice (a single letter) in double square brackets.'
}
```
This list of records can be turned into a `pandas.DataFrame` by `pandas.DataFrame(..)`. The dataframe contains columns `['Gender', 'PremiumPupil', 'Age', 'PROMPT']`.

## `opinionqa_data.json`

Consolidated OpinionQA dataset for survey simulations. Contains question metadata, choices to numeric mapping, survey responses, and synthetic profiles for selected questions.

**File Format**: JSON object keyed by question IDs ("0", "1", "2", ..., "384"). Each entry is a dictionary with the following keys:
* `old_id` (str): Original question ID from the OpinionQA dataset
* `question` (str): Question/problem statement
* `choices_to_numeric` (dict): Dictionary that maps a string choice (e.g., "A lot") to a numeric score in {-1, -1/3, 0, 1/3, 1}
* `survey` (list of dicts): Survey response records for this question with `records` orientation (i.e., obtained from `df.to_dict(orient='records')`). An example record: 
```
{
    'RESPONSE': 'Not much',
    'CREGION': 'West',
    'AGE': '65+',
    'SEX': 'Male',
    'EDUCATION': 'College graduate/some postgrad',
    'CITIZEN': 'Yes',
    'MARITAL': 'Never been married',
    'RELIG': 'Nothing in particular',
    'RELIGATTEND': 'Seldom',
    'POLPARTY': 'Republican',
    'INCOME': '$50,000-$75,000',
    'POLIDEOLOGY': 'Very conservative',
    'RACE': 'White',
    'RESPONSE_NUMERIC': -0.33333333333333337
}
```
This list of records can be turned into a `pandas.DataFrame` by `pandas.DataFrame(..)`. The dataframe contains columns `['RESPONSE', 'CREGION', 'AGE', 'SEX', 'EDUCATION', 'CITIZEN', 'MARITAL', 'RELIG', 'RELIGATTEND', 'POLPARTY', 'INCOME', 'POLIDEOLOGY', 'RACE', 'RESPONSE_NUMERIC']`.
* `synthetic_profile` (list of dicts): Synthetic profile records for this question with `records` orientation (i.e., obtained from `df.to_dict(orient='records')`). The length is 200. An example record: 
```
{
    'CREGION': 'West',
    'AGE': '18-29',
    'SEX': 'Female',
    'EDUCATION': 'Some college, no degree',
    'CITIZEN': 'Yes',
    'MARITAL': 'Never been married',
    'RELIG': 'Nothing in particular',
    'RELIGATTEND': 'Never',
    'POLPARTY': 'Other',
    'INCOME': 'Less than $30,000',
    'POLIDEOLOGY': 'Liberal',
    'RACE': 'White',
    'PROMPT': "Pretend that you reside in the US and you are a US citizen from the West region of the country. You are female, your age is between 18 and 29, and you are single. In terms of race, you are white. In terms of education, you attended college but did not graduate. Your annual income is less than $30,000. Religion-wise, you do not belong to any particular religion, and you never attend religious services. Politically, you are affiliated with a political party that is not Democratic or Republican, and you consider your political ideology to be liberal. Please answer the following question: \n\n[How much, if at all, do you think what happens to black people in the country overall affects what happens in your own life? ['1. A lot', '2. Some', '3. Not much', '4. Not at all', '5. Refused'].] \n\nPlease provide your answer choice (a single number from 1 to 5) in double square brackets."
}
```
This list of records can be turned into a `pandas.DataFrame` by `pandas.DataFrame(..)`. The dataframe contains columns `['CREGION', 'AGE', 'SEX', 'EDUCATION', 'CITIZEN', 'MARITAL', 'RELIG', 'RELIGATTEND', 'POLPARTY', 'INCOME', 'POLIDEOLOGY', 'RACE', 'PROMPT']`.

## EEDI/synthetic_answers/raw/{llm_name}.json

Raw synthetic answers for the EEDI dataset from the LLM `{llm_name}`.

**File Format**: JSON object keyed by question IDs ("0", "1", "2", ..., "411"). Each entry is a list of strings, where each string is a raw LLM response for that question. Most models have 50 responses per question, but `gpt-5-mini` has 100 responses per question.

**Example response string**:
```
"As an 11-year-old student who might have started learning about multiplication and square numbers, I'm likely to have a basic understanding but could still make mistakes...Therefore, it is plausible I might struggle and incorrectly reason or guess the statement is sometimes true instead of always true:\n\n[[B]]"
```

## EEDI/synthetic_answers/clean/{llm_name}.json (or EEDI/synthetic_answers/clean/random.json)

Clean synthetic answers for the EEDI dataset from the LLM `{llm_name}` (or random sampling).

**File Format**: JSON object keyed by question IDs ("0", "1", "2", ..., "411"). Each entry is a list of binary values (0s and 1s), where:
- `0` represents an incorrect answer
- `1` represents a correct answer

**Note**: Most models have 50 answers per question, but `gpt-5-mini` have 100 answers per question and and `random` has 200 answers per question. For evaluations, set `k_max=60` to accommodate all models.

## OpinionQA/synthetic_answers/raw/{llm_name}.json

Raw synthetic answers for the OpinionQA dataset from the LLM `{llm_name}`.

**File Format**: JSON object keyed by question IDs ("0", "1", "2", ..., "384"). Each entry is a list of strings, where each string is a raw LLM response for that question. The number of responses per question is typically 100 (except for `gpt-4o`, which has 200).

**Example response string**:
```
"Given the provided characteristics, as a moderate Republican from the South who values personal responsibility and law... my answer would likely reflect a moderate stance.\n\n[[2]]"
```

## OpinionQA/synthetic_answers/clean/{llm_name}.json (or OpinionQA/synthetic_answers/clean/random.json)

Clean synthetic answers for the OpinionQA dataset from the LLM `{llm_name}` (or random sampling).

**File Format**: JSON object keyed by question IDs ("0", "1", "2", ..., "384"). Each entry is a list of numeric scores in {-1, -1/3, 0, 1/3, 1}, where:
- `-1`: Strongly negative opinion
- `-1/3`: Somewhat negative opinion
- `0`: Neutral or refused response
- `1/3`: Somewhat positive opinion
- `1`: Strongly positive opinion

The number of responses per question is typically 100 (except for `gpt-4o`, which has 200, and `random`, which has 200).